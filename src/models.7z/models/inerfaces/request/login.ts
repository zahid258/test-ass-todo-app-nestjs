export interface ILoginRequest {
    userName: string;
    password: string;
}