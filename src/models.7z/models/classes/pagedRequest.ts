export class PagedRequest {
    pageNo: number = 1;
    pageSize: number = 10;
    getAllRecords: boolean = false;
}