export enum FilterOperators {
    And = 1,
    Or = 2
  }