// src/app.module.ts
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { databaseConfig } from './config/database.config';
import { ControllerModule } from './api/controller.module';
import { EntitiesModule } from './entities/entities.module';
import { RepositoryModule } from './dal';
import { ServiceModule } from './bl/service.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [databaseConfig],
    }),
    
    // MongoDB Configuration
    MongooseModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        const mongoConfig = configService.get('database.mongodb');
        return {
          uri: mongoConfig.uri,
          ...mongoConfig.options,
        };
      },
    }),
    
    // PostgreSQL Configuration
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: async (configService: ConfigService): Promise<TypeOrmModuleOptions> => {
        return configService.get('database.postgres') as TypeOrmModuleOptions;
      },
    }),
    ControllerModule,
    EntitiesModule,
    RepositoryModule,
    ServiceModule
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}