export enum UserStatus {
    Online = 0,
    Offline = 1,
    Away = 2,
    Busy = 3,
    Idle = 4
}