export enum SortOrder {
    Ascending = 0,
    Descending = 1
  }