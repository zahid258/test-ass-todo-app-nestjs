export enum Actions {
    Add = 1,
    Delete = 3,
    Update = 5,
}