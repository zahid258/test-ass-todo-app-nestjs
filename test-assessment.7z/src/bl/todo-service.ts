import { Injectable } from "@nestjs/common";
import { ToDo } from "../entities";
import { IToDoRequest, IToDoResponse } from "../models";
import { Service } from "./generics";
import { ToDoRepository } from "src/dal/todo-repository";

@Injectable()
export class ToDoService extends Service<ToDo, IToDoResponse, IToDoRequest> {
    constructor( private readonly toDoRepository: ToDoRepository) {
        super(toDoRepository, () => new ToDo)
    }

}
