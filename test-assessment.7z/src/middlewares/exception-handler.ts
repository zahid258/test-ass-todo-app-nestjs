// import { FastifyReply, FastifyError, FastifyRequest } from "fastify";
// import { ExtendedRequest } from "../models";

// export const errorHandler = async (
//   err: FastifyError,
//   req: ExtendedRequest | FastifyRequest,
//   res: FastifyReply
// ) => {
//     console.error(err);
//   const request = req as ExtendedRequest;
//   if(request.activityLog) {
//     await request.activityLog.logEnd('error', JSON.stringify(err));
//     request.activityLog = undefined;
//   }

//   if (err.cause === 401) {
//     res.status(401).send({error: 'User-Name or Password not found.'});
//   }
//   let errorCode = 500;
//   try{
//     errorCode = parseInt(err.code) ?? 500;
//   } catch(err){

//   }
//   res.status(errorCode).send(err);
// };